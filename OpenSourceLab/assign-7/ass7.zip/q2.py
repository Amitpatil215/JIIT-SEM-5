import pandas as pd
data = pd.read_csv("OpenSourceLab/assign-7/iris.csv")
print(data.describe())

"""
       150\t4\tsetosa\tversicolor\tvirginica
count                                    150
unique                                   149
top                    5.8\t2.7\t5.1\t1.9\t2
freq                                       2
 """
